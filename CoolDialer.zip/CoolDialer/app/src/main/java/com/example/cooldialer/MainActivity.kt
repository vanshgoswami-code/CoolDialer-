@file:OptIn(ExperimentalFoundationApi::class)

package com.example.cooldialer

import android.Manifest
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.BlockedNumberContract
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telecom.TelecomManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        edgeToEdgeDark()
        // Opened from a tel: link: prefill the number.
        val initial = intent?.data?.takeIf { it.scheme == "tel" }?.schemeSpecificPart.orEmpty()
        setContent {
            GlassTheme {
                DialerApp(initial, resumeTick.intValue)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Reload contacts and recents after coming back from edit / permission screens.
        resumeTick.intValue++
    }
}

/* ---------- data ---------- */

data class CallEntry(val number: String, val name: String?, val type: Int, val date: Long)

data class ContactItem(
    val id: Long,
    val lookupKey: String,
    val name: String,
    val numbers: List<String>,
    val starred: Boolean
)

data class SheetData(val title: String, val numbers: List<String>, val contact: ContactItem?)

fun digitsOf(s: String): String = s.filter { it.isDigit() }

fun sameNumber(a: String, b: String): Boolean {
    val x = digitsOf(a).takeLast(10)
    val y = digitsOf(b).takeLast(10)
    return x.isNotEmpty() && x == y
}

fun findContact(contacts: List<ContactItem>, number: String): ContactItem? =
    if (number.isBlank()) null else contacts.firstOrNull { c -> c.numbers.any { sameNumber(it, number) } }

fun initialOf(name: String): Char {
    val c = name.trim().firstOrNull()?.uppercaseChar()
    return if (c != null && c.isLetter()) c else '#'
}

fun letterToDigit(c: Char): Char? = when (c.lowercaseChar()) {
    'a', 'b', 'c' -> '2'
    'd', 'e', 'f' -> '3'
    'g', 'h', 'i' -> '4'
    'j', 'k', 'l' -> '5'
    'm', 'n', 'o' -> '6'
    'p', 'q', 'r', 's' -> '7'
    't', 'u', 'v' -> '8'
    'w', 'x', 'y', 'z' -> '9'
    in '0'..'9' -> c
    else -> null
}

fun t9(s: String): String = s.mapNotNull { letterToDigit(it) }.joinToString("")

/** Contacts whose name (typed on a phone keypad) or number matches the digits on the keypad. */
fun matchContacts(all: List<ContactItem>, typed: String): List<ContactItem> {
    if (typed.isEmpty() || !typed.all { it.isDigit() }) return emptyList()
    return all.filter { c ->
        c.name.split(' ').any { t9(it).startsWith(typed) } ||
            t9(c.name).startsWith(typed) ||
            (typed.length >= 3 && c.numbers.any { digitsOf(it).contains(typed) })
    }.take(2)
}

fun loadContacts(context: Context): List<ContactItem> {
    val map = LinkedHashMap<Long, ContactItem>()
    try {
        context.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(
                Phone.CONTACT_ID, Phone.LOOKUP_KEY, Phone.DISPLAY_NAME,
                Phone.NUMBER, ContactsContract.Contacts.STARRED
            ),
            null, null, "${Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val lookup = c.getString(1).orEmpty()
                val name = c.getString(2).orEmpty()
                val num = c.getString(3).orEmpty()
                val starred = c.getInt(4) == 1
                val existing = map[id]
                if (existing == null) {
                    map[id] = ContactItem(id, lookup, name, listOf(num), starred)
                } else if (existing.numbers.none { sameNumber(it, num) }) {
                    map[id] = existing.copy(numbers = existing.numbers + num)
                }
            }
        }
    } catch (_: SecurityException) {
    }
    return map.values.toList()
}

fun loadCallLog(context: Context): List<CallEntry> {
    val result = mutableListOf<CallEntry>()
    try {
        context.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(
                CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE, CallLog.Calls.DATE
            ),
            null, null, "${CallLog.Calls.DATE} DESC"
        )?.use { c ->
            while (c.moveToNext() && result.size < 200) {
                result += CallEntry(
                    number = c.getString(0).orEmpty(),
                    name = c.getString(1),
                    type = c.getInt(2),
                    date = c.getLong(3)
                )
            }
        }
    } catch (_: SecurityException) {
    }
    return result
}

fun placeCall(context: Context, number: String) {
    val uri = Uri.fromParts("tel", number, null)
    try {
        context.getSystemService(TelecomManager::class.java).placeCall(uri, Bundle())
    } catch (_: SecurityException) {
        context.startActivity(
            Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

fun safeStart(ctx: Context, intent: Intent) {
    try {
        ctx.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app found for this action", Toast.LENGTH_SHORT).show()
    }
}

fun smsIntent(number: String) = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))

fun newContactIntent(number: String?) = Intent(ContactsContract.Intents.Insert.ACTION).apply {
    type = ContactsContract.RawContacts.CONTENT_TYPE
    if (!number.isNullOrBlank()) putExtra(ContactsContract.Intents.Insert.PHONE, number)
}

fun editContactIntent(c: ContactItem) = Intent(Intent.ACTION_EDIT).apply {
    setDataAndType(
        ContactsContract.Contacts.getLookupUri(c.id, c.lookupKey),
        ContactsContract.Contacts.CONTENT_ITEM_TYPE
    )
    putExtra("finishActivityOnSaveCompleted", true)
}

fun setStarred(ctx: Context, id: Long, value: Boolean): Boolean = try {
    val v = ContentValues().apply { put(ContactsContract.Contacts.STARRED, if (value) 1 else 0) }
    ctx.contentResolver.update(
        ContactsContract.Contacts.CONTENT_URI, v,
        "${ContactsContract.Contacts._ID} = ?", arrayOf(id.toString())
    ) > 0
} catch (_: SecurityException) {
    false
}

/** Only works while Cool Dialer is the default phone app. */
fun blockNumber(ctx: Context, number: String): Boolean = try {
    val v = ContentValues().apply {
        put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, number)
    }
    ctx.contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI, v) != null
} catch (_: Exception) {
    false
}

fun copyText(ctx: Context, text: String) {
    ctx.getSystemService(ClipboardManager::class.java)
        .setPrimaryClip(ClipData.newPlainText("number", text))
    Toast.makeText(ctx, "Number copied", Toast.LENGTH_SHORT).show()
}

fun isDefaultDialer(ctx: Context): Boolean =
    ctx.getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_DIALER)

/* ---------- permission helpers ---------- */

@Composable
fun rememberPermission(permission: String): Pair<Boolean, () -> Unit> {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
    }
    return granted to { launcher.launch(permission) }
}

@Composable
fun AskNotificationPermission() {
    if (Build.VERSION.SDK_INT < 33) return
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        val granted = ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
}

/** Returns a function that places a call, asking for phone permission first if needed. */
@Composable
fun rememberCaller(): (String) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<String?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val n = pending
        pending = null
        if (granted && n != null) placeCall(ctx, n)
    }
    return { number ->
        if (number.isNotBlank()) {
            val granted = ContextCompat.checkSelfPermission(
                ctx, Manifest.permission.CALL_PHONE
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                placeCall(ctx, number)
            } else {
                pending = number
                launcher.launch(Manifest.permission.CALL_PHONE)
            }
        }
    }
}

/* ---------- app shell ---------- */

@Composable
fun DialerApp(initialNumber: String, refresh: Int) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var number by remember { mutableStateOf(initialNumber) }
    var contacts by remember { mutableStateOf<List<ContactItem>>(emptyList()) }
    var sheet by remember { mutableStateOf<SheetData?>(null) }
    var localRefresh by remember { mutableIntStateOf(0) }
    val (contactsGranted, askContacts) = rememberPermission(Manifest.permission.READ_CONTACTS)

    AskNotificationPermission()

    LaunchedEffect(contactsGranted, refresh, localRefresh) {
        if (contactsGranted) contacts = withContext(Dispatchers.IO) { loadContacts(ctx) }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> DialPad(
                    number = number,
                    contacts = contacts,
                    onChange = { number = it },
                    onAddContact = { safeStart(ctx, newContactIntent(number)) }
                )
                1 -> Recents(
                    refresh = refresh,
                    contacts = contacts,
                    onOpen = { e ->
                        val c = findContact(contacts, e.number)
                        sheet = if (c != null) {
                            SheetData(c.name, c.numbers, c)
                        } else {
                            SheetData(
                                e.name?.takeIf { it.isNotBlank() } ?: e.number.ifBlank { "Unknown" },
                                listOf(e.number).filter { it.isNotBlank() },
                                null
                            )
                        }
                    }
                )
                else -> ContactsTab(
                    contacts = contacts,
                    granted = contactsGranted,
                    onAsk = askContacts,
                    onOpen = { sheet = SheetData(it.name, it.numbers, it) }
                )
            }
        }
        GlassTabBar(tab) { tab = it }
    }

    sheet?.let { data ->
        ContactSheet(
            data = data,
            onDismiss = { sheet = null },
            onChanged = { localRefresh++ }
        )
    }
}

@Composable
fun GlassTabBar(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .glass(RoundedCornerShape(32.dp), 0.12f)
            .padding(6.dp)
    ) {
        TabItem("Keypad", Icons.Default.Dialpad, selected == 0, Modifier.weight(1f)) { onSelect(0) }
        TabItem("Recents", Icons.Default.History, selected == 1, Modifier.weight(1f)) { onSelect(1) }
        TabItem("Contacts", Icons.Default.Contacts, selected == 2, Modifier.weight(1f)) { onSelect(2) }
    }
}

@Composable
fun TabItem(
    label: String,
    icon: ImageVector,
    active: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val tint = if (active) Color.White else Color.White.copy(alpha = 0.6f)
    Row(
        modifier
            .glass(RoundedCornerShape(26.dp), if (active) 0.26f else 0.08f)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = tint, fontSize = 12.sp, maxLines = 1)
    }
}

/* ---------- shared pieces ---------- */

@Composable
fun GlassSearchBar(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
    Row(
        modifier
            .glass(RoundedCornerShape(28.dp), 0.12f)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Search, null, tint = Color.White.copy(alpha = 0.7f))
        Spacer(Modifier.width(12.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(hint, color = Color.White.copy(alpha = 0.45f), fontSize = 16.sp)
            }
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Color.White),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (value.isNotEmpty()) {
            Icon(
                Icons.Default.Close, "Clear",
                tint = Color.White.copy(alpha = 0.7f),
                modifier = Modifier.size(20.dp).clickable { onChange("") }
            )
        }
    }
}

@Composable
fun Avatar(name: String, size: androidx.compose.ui.unit.Dp) {
    Box(
        Modifier.size(size).glass(CircleShape, 0.16f),
        contentAlignment = Alignment.Center
    ) {
        Text(
            initialOf(name).toString(),
            color = Color.White,
            fontSize = (size.value * 0.42f).sp,
            fontWeight = FontWeight.Light
        )
    }
}

@Composable
fun PermissionCard(text: String, onAllow: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(
            Modifier.glass(RoundedCornerShape(24.dp), 0.12f).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text, color = Color.White, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onAllow,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GlassColors.Mint,
                    contentColor = GlassColors.Ink
                )
            ) { Text("Allow") }
        }
    }
}

@Composable
fun EmptyNote(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White.copy(alpha = 0.6f))
    }
}

/* ---------- keypad ---------- */

@Composable
fun DialPad(
    number: String,
    contacts: List<ContactItem>,
    onChange: (String) -> Unit,
    onAddContact: () -> Unit
) {
    val call = rememberCaller()
    val suggestions = remember(number, contacts) { matchContacts(contacts, number) }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        DefaultDialerBanner()

        Column(
            Modifier.fillMaxWidth().weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = number.ifEmpty { "Enter number" },
                fontSize = if (number.length > 12) 28.sp else 38.sp,
                fontWeight = FontWeight.Light,
                color = if (number.isEmpty()) Color.White.copy(alpha = 0.45f) else Color.White,
                maxLines = 1
            )
            if (suggestions.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    suggestions.forEach { c ->
                        Column(
                            Modifier
                                .weight(1f)
                                .glass(RoundedCornerShape(16.dp), 0.12f)
                                .clickable { onChange(c.numbers.first()) }
                                .padding(10.dp)
                        ) {
                            Text(
                                c.name, color = Color.White, fontSize = 14.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                c.numbers.first(), color = Color.White.copy(alpha = 0.6f),
                                fontSize = 12.sp, maxLines = 1
                            )
                        }
                    }
                    if (suggestions.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        val keys = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to "", "0" to "+", "#" to "")
        )
        keys.forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { (digit, letters) ->
                    GlassKey(
                        digit, letters,
                        onLong = if (digit == "0") ({ onChange(number + "+") }) else null
                    ) { onChange(number + digit) }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(76.dp), contentAlignment = Alignment.Center) {
                if (number.isNotEmpty()) {
                    GlassCircle(56.dp, onClick = onAddContact) {
                        Icon(Icons.Default.PersonAdd, "Add to contacts", tint = Color.White)
                    }
                }
            }
            GlassCircle(76.dp, tint = GlassColors.Go, onClick = { call(number) }) {
                Icon(Icons.Default.Call, "Call", tint = Color.White, modifier = Modifier.size(34.dp))
            }
            Box(
                Modifier
                    .size(76.dp)
                    .combinedClickable(
                        enabled = number.isNotEmpty(),
                        onLongClick = { onChange("") },
                        onClick = { onChange(number.dropLast(1)) }
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (number.isNotEmpty()) {
                    Icon(Icons.Default.Backspace, "Delete", tint = Color.White.copy(alpha = 0.8f))
                }
            }
        }
    }
}

@Composable
fun GlassKey(digit: String, letters: String, onLong: (() -> Unit)? = null, onClick: () -> Unit) {
    Box(
        Modifier
            .size(72.dp)
            .glass(CircleShape, 0.12f)
            .combinedClickable(onLongClick = onLong, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(digit, fontSize = 28.sp, color = Color.White)
            if (letters.isNotEmpty()) {
                Text(letters, fontSize = 9.sp, color = Color.White.copy(alpha = 0.6f))
            }
        }
    }
}

/** Asks to become the default phone app, which turns on our own call screen. */
@Composable
fun DefaultDialerBanner() {
    val ctx = LocalContext.current
    var isDefault by remember { mutableStateOf(isDefaultDialer(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        isDefault = isDefaultDialer(ctx)
    }
    if (isDefault) return

    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .glass(RoundedCornerShape(20.dp), 0.14f)
            .padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Use Cool Dialer for all calls",
            color = Color.White,
            fontSize = 14.sp,
            modifier = Modifier.weight(1f)
        )
        Button(
            onClick = {
                val rm = ctx.getSystemService(RoleManager::class.java)
                launcher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = GlassColors.Mint,
                contentColor = GlassColors.Ink
            )
        ) { Text("Set default") }
    }
}

/* ---------- recents ---------- */

@Composable
fun Recents(refresh: Int, contacts: List<ContactItem>, onOpen: (CallEntry) -> Unit) {
    val context = LocalContext.current
    val call = rememberCaller()
    var entries by remember { mutableStateOf<List<CallEntry>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var missedOnly by remember { mutableStateOf(false) }
    val (hasPermission, askPermission) = rememberPermission(Manifest.permission.READ_CALL_LOG)

    LaunchedEffect(hasPermission, refresh) {
        if (hasPermission) entries = withContext(Dispatchers.IO) { loadCallLog(context) }
    }

    if (!hasPermission) {
        PermissionCard("Allow access to your call history to see recent calls.", askPermission)
        return
    }

    fun nameFor(e: CallEntry): String =
        e.name?.takeIf { it.isNotBlank() }
            ?: findContact(contacts, e.number)?.name
            ?: e.number.ifBlank { "Unknown" }

    val shown = remember(entries, query, missedOnly, contacts) {
        val q = query.trim()
        entries.filter { e ->
            (!missedOnly || e.type == CallLog.Calls.MISSED_TYPE) &&
                (q.isEmpty() ||
                    nameFor(e).contains(q, ignoreCase = true) ||
                    e.number.contains(q))
        }
    }

    Column(Modifier.fillMaxSize()) {
        GlassSearchBar(
            query, { query = it }, "Search recents",
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
        )
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterPill("All", !missedOnly) { missedOnly = false }
            FilterPill("Missed", missedOnly) { missedOnly = true }
        }

        if (shown.isEmpty()) {
            EmptyNote(if (entries.isEmpty()) "No recent calls" else "No matching calls")
            return@Column
        }

        val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(shown) { e ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(20.dp), 0.10f)
                        .clickable { onOpen(e) }
                        .padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val (icon, tint) = when (e.type) {
                        CallLog.Calls.OUTGOING_TYPE -> Icons.Default.CallMade to GlassColors.Go
                        CallLog.Calls.MISSED_TYPE -> Icons.Default.CallMissed to Color(0xFFFF6B6B)
                        else -> Icons.Default.CallReceived to GlassColors.Mint
                    }
                    Icon(icon, null, tint = tint)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            nameFor(e), color = Color.White, fontSize = 17.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            fmt.format(Date(e.date)),
                            color = Color.White.copy(alpha = 0.55f),
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = { call(e.number) }) {
                        Icon(Icons.Default.Call, "Call back", tint = GlassColors.Mint)
                    }
                }
            }
        }
    }
}

@Composable
fun FilterPill(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) Color.White else Color.White.copy(alpha = 0.65f),
        fontSize = 13.sp,
        modifier = Modifier
            .glass(RoundedCornerShape(20.dp), if (selected) 0.26f else 0.08f)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 7.dp)
    )
}

/* ---------- contacts ---------- */

@Composable
fun ContactsTab(
    contacts: List<ContactItem>,
    granted: Boolean,
    onAsk: () -> Unit,
    onOpen: (ContactItem) -> Unit
) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassSearchBar(query, { query = it }, "Search contacts", Modifier.weight(1f))
            Spacer(Modifier.width(10.dp))
            GlassCircle(52.dp, onClick = { safeStart(ctx, newContactIntent(null)) }) {
                Icon(Icons.Default.PersonAdd, "New contact", tint = Color.White)
            }
        }

        if (!granted) {
            PermissionCard("Allow access to your contacts to see and search them.", onAsk)
            return@Column
        }

        val q = query.trim()
        val qDigits = digitsOf(q)
        val filtered = remember(contacts, q) {
            if (q.isEmpty()) {
                contacts
            } else {
                contacts.filter { c ->
                    c.name.contains(q, ignoreCase = true) ||
                        (qDigits.length >= 2 && c.numbers.any { digitsOf(it).contains(qDigits) })
                }
            }
        }
        if (filtered.isEmpty()) {
            EmptyNote(if (contacts.isEmpty()) "No contacts yet" else "No matching contacts")
            return@Column
        }

        val favorites = remember(filtered, q) {
            if (q.isEmpty()) filtered.filter { it.starred } else emptyList()
        }
        val sections = remember(filtered) {
            filtered.groupBy { initialOf(it.name) }
                .toList()
                .sortedBy { (letter, _) -> if (letter == '#') '￿' else letter }
        }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            if (favorites.isNotEmpty()) {
                item { SectionHeader("Favorites") }
                items(favorites) { ContactRow(it) { onOpen(it) } }
            }
            sections.forEach { (letter, list) ->
                item { SectionHeader(letter.toString()) }
                items(list) { ContactRow(it) { onOpen(it) } }
            }
            item {
                Text(
                    "${filtered.size} contacts",
                    color = Color.White.copy(alpha = 0.45f),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                )
            }
        }
    }
}

@Composable
fun SectionHeader(text: String) {
    Text(
        text,
        color = GlassColors.Mint,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 20.dp, top = 14.dp, bottom = 4.dp)
    )
}

@Composable
fun ContactRow(c: ContactItem, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(c.name, 44.dp)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(
                c.name, color = Color.White, fontSize = 17.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                c.numbers.first(), color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp,
                maxLines = 1
            )
        }
        if (c.starred) {
            Icon(Icons.Default.Star, "Favorite", tint = Color(0xFFFFD166), modifier = Modifier.size(18.dp))
        }
    }
}

/* ---------- contact / number details ---------- */

@Composable
fun ContactSheet(data: SheetData, onDismiss: () -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val call = rememberCaller()
    val contact = data.contact
    var starred by remember { mutableStateOf(contact?.starred ?: false) }

    fun toggleStar() {
        if (contact == null) return
        val next = !starred
        if (setStarred(ctx, contact.id, next)) {
            starred = next
            onChanged()
        } else {
            Toast.makeText(ctx, "Could not change favorite", Toast.LENGTH_SHORT).show()
        }
    }

    val writeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) toggleStar()
    }

    val shape = RoundedCornerShape(28.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Color(0xFF14183F).copy(alpha = 0.92f))
                .glass(shape, 0.10f)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Avatar(data.title, 72.dp)
            Spacer(Modifier.height(12.dp))
            Text(
                data.title, color = Color.White, fontSize = 24.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))

            data.numbers.forEach { n ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(20.dp), 0.08f)
                        .padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(n, color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { safeStart(ctx, smsIntent(n)) }) {
                        Icon(Icons.Default.Sms, "Message", tint = Color.White)
                    }
                    GlassCircle(44.dp, tint = GlassColors.Go, onClick = {
                        onDismiss()
                        call(n)
                    }) {
                        Icon(Icons.Default.Call, "Call", tint = Color.White)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            Spacer(Modifier.height(8.dp))

            if (contact != null) {
                SheetAction(
                    if (starred) Icons.Default.Star else Icons.Default.StarBorder,
                    if (starred) "Remove from favorites" else "Add to favorites"
                ) {
                    val granted = ContextCompat.checkSelfPermission(
                        ctx, Manifest.permission.WRITE_CONTACTS
                    ) == PackageManager.PERMISSION_GRANTED
                    if (granted) toggleStar() else writeLauncher.launch(Manifest.permission.WRITE_CONTACTS)
                }
                SheetAction(Icons.Default.Edit, "Edit contact") {
                    safeStart(ctx, editContactIntent(contact))
                    onDismiss()
                }
            } else if (data.numbers.isNotEmpty()) {
                SheetAction(Icons.Default.PersonAdd, "Add to contacts") {
                    safeStart(ctx, newContactIntent(data.numbers.first()))
                    onDismiss()
                }
            }
            if (data.numbers.isNotEmpty()) {
                SheetAction(Icons.Default.ContentCopy, "Copy number") {
                    copyText(ctx, data.numbers.first())
                }
                if (isDefaultDialer(ctx)) {
                    SheetAction(Icons.Default.Block, "Block number") {
                        val ok = data.numbers.map { blockNumber(ctx, it) }.any { it }
                        Toast.makeText(
                            ctx,
                            if (ok) "Number blocked" else "Could not block this number",
                            Toast.LENGTH_SHORT
                        ).show()
                        if (ok) onDismiss()
                    }
                }
            }
            TextButton(onClick = onDismiss) { Text("Close", color = Color.White.copy(alpha = 0.8f)) }
        }
    }
}

@Composable
fun SheetAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = GlassColors.Mint)
        Spacer(Modifier.width(16.dp))
        Text(label, color = Color.White, fontSize = 16.sp)
    }
}
