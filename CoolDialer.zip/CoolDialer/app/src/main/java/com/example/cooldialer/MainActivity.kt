@file:OptIn(ExperimentalFoundationApi::class)

package com.example.cooldialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.telecom.TelecomManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        edgeToEdgeDark()
        // Opened from a tel: link: prefill the number.
        val initial = intent?.data?.takeIf { it.scheme == "tel" }?.schemeSpecificPart.orEmpty()
        setContent {
            GlassTheme {
                DialerApp(initial)
            }
        }
    }
}

data class CallEntry(val number: String, val name: String?, val type: Int, val date: Long)

@Composable
fun DialerApp(initialNumber: String) {
    var tab by remember { mutableIntStateOf(0) }
    var number by remember { mutableStateOf(initialNumber) }

    AskNotificationPermission()

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Box(Modifier.weight(1f)) {
            if (tab == 0) {
                DialPad(number, onChange = { number = it })
            } else {
                Recents(onPick = { number = it; tab = 0 })
            }
        }
        GlassTabBar(tab) { tab = it }
    }
}

@Composable
fun GlassTabBar(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 40.dp, vertical = 12.dp)
            .glass(RoundedCornerShape(32.dp), 0.12f)
            .padding(6.dp)
    ) {
        TabItem("Keypad", Icons.Default.Dialpad, selected == 0, Modifier.weight(1f)) { onSelect(0) }
        TabItem("Recents", Icons.Default.History, selected == 1, Modifier.weight(1f)) { onSelect(1) }
    }
}

@Composable
fun TabItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier
            .glass(RoundedCornerShape(26.dp), if (active) 0.26f else 0.0f + 0.08f)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, label, tint = if (active) Color.White else Color.White.copy(alpha = 0.6f))
        Spacer(Modifier.width(8.dp))
        Text(
            label,
            color = if (active) Color.White else Color.White.copy(alpha = 0.6f),
            fontSize = 14.sp
        )
    }
}

@Composable
fun DialPad(number: String, onChange: (String) -> Unit) {
    val call = rememberCaller()

    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        DefaultDialerBanner()

        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            Text(
                text = number.ifEmpty { "Enter number" },
                fontSize = if (number.length > 12) 28.sp else 38.sp,
                fontWeight = FontWeight.Light,
                color = if (number.isEmpty()) Color.White.copy(alpha = 0.45f) else Color.White,
                maxLines = 1
            )
        }

        val keys = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to "", "0" to "+", "#" to "")
        )
        keys.forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { (digit, letters) ->
                    GlassKey(
                        digit, letters,
                        onLong = if (digit == "0") ({ onChange(number + "+") }) else null
                    ) { onChange(number + digit) }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.size(76.dp))
            GlassCircle(76.dp, tint = GlassColors.Go, onClick = { call(number) }) {
                Icon(Icons.Default.Call, "Call", tint = Color.White, modifier = Modifier.size(34.dp))
            }
            Box(
                Modifier
                    .size(76.dp)
                    .combinedClickable(
                        enabled = number.isNotEmpty(),
                        onLongClick = { onChange("") },
                        onClick = { onChange(number.dropLast(1)) }
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (number.isNotEmpty()) {
                    Icon(Icons.Default.Backspace, "Delete", tint = Color.White.copy(alpha = 0.8f))
                }
            }
        }
    }
}

@Composable
fun GlassKey(digit: String, letters: String, onLong: (() -> Unit)? = null, onClick: () -> Unit) {
    Box(
        Modifier
            .size(72.dp)
            .glass(CircleShape, 0.12f)
            .combinedClickable(onLongClick = onLong, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(digit, fontSize = 28.sp, color = Color.White)
            if (letters.isNotEmpty()) {
                Text(letters, fontSize = 9.sp, color = Color.White.copy(alpha = 0.6f))
            }
        }
    }
}

/** Asks to become the default phone app, which is what turns on our own call screen. */
@Composable
fun DefaultDialerBanner() {
    val ctx = LocalContext.current
    var isDefault by remember { mutableStateOf(isDefaultDialer(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        isDefault = isDefaultDialer(ctx)
    }
    if (isDefault) return

    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .glass(RoundedCornerShape(20.dp), 0.14f)
            .padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Use Cool Dialer for all calls",
            color = Color.White,
            fontSize = 14.sp,
            modifier = Modifier.weight(1f)
        )
        Button(
            onClick = {
                val rm = ctx.getSystemService(RoleManager::class.java)
                launcher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = GlassColors.Mint,
                contentColor = GlassColors.Ink
            )
        ) { Text("Set default") }
    }
}

fun isDefaultDialer(ctx: Context): Boolean =
    ctx.getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_DIALER)

@Composable
fun AskNotificationPermission() {
    if (Build.VERSION.SDK_INT < 33) return
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        val granted = ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
}

/** Returns a function that places a call, asking for phone permission first if needed. */
@Composable
fun rememberCaller(): (String) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<String?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val n = pending
        pending = null
        if (granted && n != null) placeCall(ctx, n)
    }
    return { number ->
        if (number.isNotBlank()) {
            val granted = ContextCompat.checkSelfPermission(
                ctx, Manifest.permission.CALL_PHONE
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                placeCall(ctx, number)
            } else {
                pending = number
                launcher.launch(Manifest.permission.CALL_PHONE)
            }
        }
    }
}

@Composable
fun Recents(onPick: (String) -> Unit) {
    val context = LocalContext.current
    val call = rememberCaller()
    var entries by remember { mutableStateOf<List<CallEntry>>(emptyList()) }
    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALL_LOG) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasPermission = it
    }

    LaunchedEffect(hasPermission) {
        if (hasPermission) entries = loadCallLog(context)
    }

    when {
        !hasPermission -> {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Column(
                    Modifier.glass(RoundedCornerShape(24.dp), 0.12f).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Allow access to your call history to see recent calls.",
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = { launcher.launch(Manifest.permission.READ_CALL_LOG) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GlassColors.Mint,
                            contentColor = GlassColors.Ink
                        )
                    ) { Text("Allow") }
                }
            }
        }
        entries.isEmpty() -> {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No recent calls", color = Color.White.copy(alpha = 0.6f))
            }
        }
        else -> {
            val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(entries) { e ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .glass(RoundedCornerShape(20.dp), 0.10f)
                            .clickable { onPick(e.number) }
                            .padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val (icon, tint) = when (e.type) {
                            CallLog.Calls.OUTGOING_TYPE -> Icons.Default.CallMade to GlassColors.Go
                            CallLog.Calls.MISSED_TYPE -> Icons.Default.CallMissed to Color(0xFFFF6B6B)
                            else -> Icons.Default.CallReceived to GlassColors.Mint
                        }
                        Icon(icon, null, tint = tint)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                e.name?.takeIf { it.isNotBlank() } ?: e.number,
                                color = Color.White,
                                fontSize = 17.sp
                            )
                            Text(
                                fmt.format(Date(e.date)),
                                color = Color.White.copy(alpha = 0.55f),
                                fontSize = 12.sp
                            )
                        }
                        IconButton(onClick = { call(e.number) }) {
                            Icon(Icons.Default.Call, "Call back", tint = GlassColors.Mint)
                        }
                    }
                }
            }
        }
    }
}

fun loadCallLog(context: Context): List<CallEntry> {
    val result = mutableListOf<CallEntry>()
    try {
        context.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(
                CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE, CallLog.Calls.DATE
            ),
            null, null, "${CallLog.Calls.DATE} DESC"
        )?.use { c ->
            while (c.moveToNext() && result.size < 100) {
                result += CallEntry(
                    number = c.getString(0).orEmpty(),
                    name = c.getString(1),
                    type = c.getInt(2),
                    date = c.getLong(3)
                )
            }
        }
    } catch (_: SecurityException) {
    }
    return result
}

fun placeCall(context: Context, number: String) {
    val uri = Uri.fromParts("tel", number, null)
    try {
        context.getSystemService(TelecomManager::class.java).placeCall(uri, Bundle())
    } catch (_: SecurityException) {
        context.startActivity(
            Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
