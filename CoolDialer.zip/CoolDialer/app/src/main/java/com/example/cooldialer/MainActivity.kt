package com.example.cooldialer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // If opened from a tel: link, prefill the number.
        val initial = intent?.data?.takeIf { it.scheme == "tel" }?.schemeSpecificPart.orEmpty()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF2ECC71),
                background = Color(0xFF0E1116),
                surface = Color(0xFF161B22)
            )) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    DialerApp(initial)
                }
            }
        }
    }
}

data class CallEntry(val number: String, val name: String?, val type: Int, val date: Long)

@Composable
fun DialerApp(initialNumber: String) {
    var tab by remember { mutableIntStateOf(0) }
    var number by remember { mutableStateOf(initialNumber) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Dialpad, null) }, label = { Text("Keypad") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.History, null) }, label = { Text("Recents") }
                )
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (tab == 0) {
                DialPad(number, onChange = { number = it })
            } else {
                Recents(onPick = { number = it; tab = 0 })
            }
        }
    }
}

@Composable
fun DialPad(number: String, onChange: (String) -> Unit) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) placeCall(context, number)
    }

    fun call() {
        if (number.isBlank()) return
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) placeCall(context, number) else launcher.launch(Manifest.permission.CALL_PHONE)
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Number display
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            Text(
                text = number.ifEmpty { "Enter number" },
                fontSize = if (number.length > 12) 28.sp else 38.sp,
                fontWeight = FontWeight.Light,
                color = if (number.isEmpty()) Color.Gray else Color.White,
                maxLines = 1
            )
        }

        val keys = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to "", "0" to "+", "#" to "")
        )
        keys.forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { (digit, letters) ->
                    Key(digit, letters) { onChange(number + digit) }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.size(76.dp))
            Box(
                Modifier.size(76.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary)
                    .clickable { call() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Call, "Call", tint = Color.White, modifier = Modifier.size(34.dp))
            }
            Box(
                Modifier.size(76.dp).clip(CircleShape)
                    .clickable(enabled = number.isNotEmpty()) { onChange(number.dropLast(1)) },
                contentAlignment = Alignment.Center
            ) {
                if (number.isNotEmpty()) {
                    Icon(Icons.Default.Backspace, "Delete", tint = Color.LightGray)
                }
            }
        }
    }
}

@Composable
fun Key(digit: String, letters: String, onClick: () -> Unit) {
    Box(
        Modifier.size(76.dp).clip(CircleShape)
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(digit, fontSize = 28.sp, color = Color.White)
            if (letters.isNotEmpty()) Text(letters, fontSize = 9.sp, color = Color.Gray)
        }
    }
}

@Composable
fun Recents(onPick: (String) -> Unit) {
    val context = LocalContext.current
    var entries by remember { mutableStateOf<List<CallEntry>>(emptyList()) }
    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALL_LOG) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasPermission = it
    }

    LaunchedEffect(hasPermission) {
        if (hasPermission) entries = loadCallLog(context)
    }

    if (!hasPermission) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Allow access to your call history to see recent calls.", color = Color.LightGray)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { launcher.launch(Manifest.permission.READ_CALL_LOG) }) {
                Text("Allow")
            }
        }
        return
    }

    if (entries.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No recent calls", color = Color.Gray)
        }
        return
    }

    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    LazyColumn(Modifier.fillMaxSize()) {
        items(entries) { e ->
            Row(
                Modifier.fillMaxWidth().clickable { onPick(e.number) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val (icon, tint) = when (e.type) {
                    CallLog.Calls.OUTGOING_TYPE -> Icons.Default.CallMade to Color(0xFF2ECC71)
                    CallLog.Calls.MISSED_TYPE -> Icons.Default.CallMissed to Color(0xFFE74C3C)
                    else -> Icons.Default.CallReceived to Color(0xFF3498DB)
                }
                Icon(icon, null, tint = tint)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(e.name?.takeIf { it.isNotBlank() } ?: e.number, color = Color.White, fontSize = 17.sp)
                    Text(fmt.format(Date(e.date)), color = Color.Gray, fontSize = 12.sp)
                }
                Icon(
                    Icons.Default.Call, "Call back", tint = Color.Gray,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

fun loadCallLog(context: android.content.Context): List<CallEntry> {
    val result = mutableListOf<CallEntry>()
    try {
        context.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(
                CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE, CallLog.Calls.DATE
            ),
            null, null, "${CallLog.Calls.DATE} DESC"
        )?.use { c ->
            while (c.moveToNext() && result.size < 100) {
                result += CallEntry(
                    number = c.getString(0).orEmpty(),
                    name = c.getString(1),
                    type = c.getInt(2),
                    date = c.getLong(3)
                )
            }
        }
    } catch (_: SecurityException) {
    }
    return result
}

fun placeCall(context: android.content.Context, number: String) {
    val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))
    try {
        context.startActivity(intent)
    } catch (_: SecurityException) {
        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
    }
}
