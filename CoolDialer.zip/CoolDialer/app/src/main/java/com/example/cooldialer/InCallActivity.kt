package com.example.cooldialer

import android.content.Intent
import android.os.Bundle
import android.telecom.Call
import android.telecom.CallAudioState
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Call as CallIcon
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class InCallActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        edgeToEdgeDark()
        handleAction(intent)
        setContent {
            GlassTheme {
                InCallScreen(onFinish = { finish() })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAction(intent)
    }

    /** Answer / Decline buttons on the incoming-call notification come in here. */
    private fun handleAction(i: Intent?) {
        val call = CallManager.primary() ?: return
        when (i?.getStringExtra(EXTRA_ACTION)) {
            "answer" -> CallManager.answer(call)
            "decline" -> CallManager.reject(call)
        }
        i?.removeExtra(EXTRA_ACTION)
    }

    companion object {
        const val EXTRA_ACTION = "action"
    }
}

@Composable
fun InCallScreen(onFinish: () -> Unit) {
    val call = CallManager.primary()
    if (call == null) {
        LaunchedEffect(Unit) {
            delay(700)
            onFinish()
        }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Call ended", color = Color.White, fontSize = 22.sp)
        }
    } else {
        CallContent(call, CallManager.tick)
    }
}

@Composable
fun CallContent(call: Call, version: Int) {
    val state = call.state
    val details = call.details
    val number = details.handle?.schemeSpecificPart.orEmpty()
    val name = details.contactDisplayName?.takeIf { it.isNotBlank() }
        ?: number.ifBlank { "Unknown" }

    var showKeypad by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(state) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    val ringing = state == Call.STATE_RINGING
    val status = when (state) {
        Call.STATE_RINGING -> "Incoming call"
        Call.STATE_DIALING, Call.STATE_CONNECTING, Call.STATE_NEW -> "Calling…"
        Call.STATE_ACTIVE -> {
            val s = ((now - details.connectTimeMillis) / 1000).coerceAtLeast(0)
            "%02d:%02d".format(s / 60, s % 60)
        }
        Call.STATE_HOLDING -> "On hold"
        else -> "Ending…"
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(32.dp))
        Box(
            Modifier
                .size(120.dp)
                .glass(CircleShape, 0.16f),
            contentAlignment = Alignment.Center
        ) {
            Text(
                name.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "#",
                fontSize = 48.sp,
                color = Color.White,
                fontWeight = FontWeight.Light
            )
        }
        Spacer(Modifier.height(20.dp))
        Text(name, fontSize = 30.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (name != number && number.isNotBlank()) {
            Text(number, color = Color.White.copy(alpha = 0.65f), fontSize = 15.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(status, color = GlassColors.Mint, fontSize = 18.sp)

        Spacer(Modifier.weight(1f))

        if (!ringing) {
            if (showKeypad) {
                Text(typed, color = Color.White, fontSize = 28.sp, maxLines = 1)
                Spacer(Modifier.height(8.dp))
                listOf("123", "456", "789", "*0#").forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        row.forEach { ch ->
                            GlassCircle(64.dp, onClick = {
                                typed += ch
                                CallManager.dtmf(call, ch)
                            }) {
                                Text(ch.toString(), fontSize = 24.sp, color = Color.White)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                TextButton(onClick = { showKeypad = false }) {
                    Text("Hide keypad", color = Color.White)
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    ControlButton(
                        if (CallManager.muted) Icons.Default.MicOff else Icons.Default.Mic,
                        "Mute", CallManager.muted
                    ) { CallManager.setMuted(!CallManager.muted) }
                    ControlButton(Icons.Default.Dialpad, "Keypad", false) { showKeypad = true }
                    ControlButton(
                        Icons.Default.VolumeUp, "Speaker",
                        CallManager.route == CallAudioState.ROUTE_SPEAKER
                    ) { CallManager.setSpeaker(CallManager.route != CallAudioState.ROUTE_SPEAKER) }
                    ControlButton(Icons.Default.Pause, "Hold", state == Call.STATE_HOLDING) {
                        CallManager.hold(call, state != Call.STATE_HOLDING)
                    }
                }
            }
        }

        Spacer(Modifier.height(32.dp))

        if (ringing) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                LabeledAction(Icons.Default.CallEnd, "Decline", GlassColors.Danger) {
                    CallManager.reject(call)
                }
                LabeledAction(Icons.Default.CallIcon, "Answer", GlassColors.Go) {
                    CallManager.answer(call)
                }
            }
        } else {
            GlassCircle(76.dp, tint = GlassColors.Danger, onClick = { CallManager.hangup(call) }) {
                Icon(
                    Icons.Default.CallEnd, "End call",
                    tint = Color.White, modifier = Modifier.size(34.dp)
                )
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun ControlButton(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        GlassCircle(64.dp, fill = if (active) 0.34f else 0.12f, onClick = onClick) {
            Icon(icon, label, tint = Color.White)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
    }
}

@Composable
fun LabeledAction(icon: ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        GlassCircle(76.dp, tint = color, onClick = onClick) {
            Icon(icon, label, tint = Color.White, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, fontSize = 14.sp, color = Color.White.copy(alpha = 0.85f))
    }
}
