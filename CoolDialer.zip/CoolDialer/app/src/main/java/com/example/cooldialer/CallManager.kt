package com.example.cooldialer

import android.app.NotificationManager
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Holds the live calls and audio state so the call screen can show them. */
object CallManager {
    var service: InCallService? = null

    val calls = mutableStateListOf<Call>()

    /** Goes up whenever any call changes, so the screen redraws. */
    var tick by mutableIntStateOf(0)

    var muted by mutableStateOf(false)
    var route by mutableIntStateOf(CallAudioState.ROUTE_EARPIECE)

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            if (state != Call.STATE_RINGING) {
                service?.getSystemService(NotificationManager::class.java)
                    ?.cancel(CallService.NOTIF_ID)
            }
            tick++
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) {
            tick++
        }
    }

    fun add(call: Call) {
        call.registerCallback(callback)
        calls.add(call)
        tick++
    }

    fun remove(call: Call) {
        call.unregisterCallback(callback)
        calls.remove(call)
        tick++
    }

    /** The call to show: a ringing one first, otherwise the oldest. */
    fun primary(): Call? {
        @Suppress("UNUSED_VARIABLE")
        val observe = tick
        return calls.firstOrNull { it.state == Call.STATE_RINGING } ?: calls.firstOrNull()
    }

    fun answer(call: Call) = call.answer(0)

    fun reject(call: Call) = call.reject(false, null)

    fun hangup(call: Call) = call.disconnect()

    fun hold(call: Call, hold: Boolean) = if (hold) call.hold() else call.unhold()

    fun setMuted(value: Boolean) {
        service?.setMuted(value)
    }

    fun setSpeaker(on: Boolean) {
        service?.setAudioRoute(if (on) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE)
    }

    fun dtmf(call: Call, digit: Char) {
        call.playDtmfTone(digit)
        call.stopDtmfTone()
    }
}
