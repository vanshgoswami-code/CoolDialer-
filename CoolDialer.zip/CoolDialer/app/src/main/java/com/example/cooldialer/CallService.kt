package com.example.cooldialer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService

/**
 * Android hands every call to this service once Cool Dialer is the default phone app.
 * It opens our own call screen instead of the system one.
 */
class CallService : InCallService() {

    override fun onCreate() {
        super.onCreate()
        CallManager.service = this
    }

    override fun onDestroy() {
        CallManager.service = null
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.add(call)
        if (call.state == Call.STATE_RINGING) {
            showIncomingNotification(call)
        } else {
            openCallScreen()
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        CallManager.remove(call)
        getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState) {
        super.onCallAudioStateChanged(audioState)
        CallManager.muted = audioState.isMuted
        CallManager.route = audioState.route
    }

    private fun openCallScreen() {
        val intent = Intent(this, InCallActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intent)
    }

    private fun showIncomingNotification(call: Call) {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID, "Incoming calls", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            setSound(null, null) // the system already plays the ringtone
            enableVibration(false)
        }
        nm.createNotificationChannel(channel)

        val number = call.details.handle?.schemeSpecificPart.orEmpty()
        val name = call.details.contactDisplayName?.takeIf { it.isNotBlank() }
            ?: number.ifBlank { "Unknown" }

        fun screen(action: String?, code: Int): PendingIntent {
            val intent = Intent(this, InCallActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                if (action != null) putExtra(InCallActivity.EXTRA_ACTION, action)
            }
            return PendingIntent.getActivity(
                this, code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        val answer = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.sym_action_call),
            "Answer", screen("answer", 2)
        ).build()
        val decline = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Decline", screen("decline", 3)
        ).build()

        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(name)
            .setContentText("Incoming call")
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setContentIntent(screen(null, 1))
            .setFullScreenIntent(screen(null, 1), true)
            .addAction(decline)
            .addAction(answer)
            .build()

        nm.notify(NOTIF_ID, notification)
    }

    companion object {
        const val CHANNEL_ID = "incoming_calls"
        const val NOTIF_ID = 42
    }
}
