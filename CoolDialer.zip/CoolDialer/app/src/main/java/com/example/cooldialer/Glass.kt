package com.example.cooldialer

import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

object GlassColors {
    val Ink = Color(0xFF080B1F)
    val Violet = Color(0xFF2A1B6B)
    val Teal = Color(0xFF0B6E7F)
    val Rose = Color(0xFFFF4D8D)
    val Mint = Color(0xFF5EEAD4)
    val Go = Color(0xFF22C55E)
    val Danger = Color(0xFFEF4444)
}

/** Transparent status and navigation bars with light icons. */
fun ComponentActivity.edgeToEdgeDark() {
    enableEdgeToEdge(
        statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
    )
}

@Composable
fun GlassTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = GlassColors.Mint,
            onSurface = Color.White,
            background = GlassColors.Ink
        )
    ) {
        GlassBackground { content() }
    }
}

/** Deep gradient with soft coloured light behind the frosted panels. */
@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(GlassColors.Ink, GlassColors.Violet, GlassColors.Teal)
                )
            )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            blob(GlassColors.Rose.copy(alpha = 0.55f), Offset(w * 0.95f, h * 0.10f), w * 0.80f)
            blob(GlassColors.Mint.copy(alpha = 0.35f), Offset(w * 0.05f, h * 0.55f), w * 0.70f)
            blob(Color(0xFF7C5CFF).copy(alpha = 0.45f), Offset(w * 0.80f, h * 0.95f), w * 0.85f)
        }
        content()
    }
}

private fun DrawScope.blob(color: Color, center: Offset, radius: Float) {
    drawCircle(
        brush = Brush.radialGradient(listOf(color, Color.Transparent), center = center, radius = radius),
        radius = radius,
        center = center
    )
}

/** Frosted panel: translucent white fill with a light edge on top-left. */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(24.dp),
    fill: Float = 0.12f
): Modifier = this
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = fill + 0.06f),
                Color.White.copy(alpha = fill - 0.04f)
            )
        )
    )
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.55f),
                Color.White.copy(alpha = 0.06f),
                Color.White.copy(alpha = 0.28f)
            )
        ),
        shape
    )

/** Round glass button. Pass [tint] for a solid colour (call / end call). */
@Composable
fun GlassCircle(
    size: Dp,
    fill: Float = 0.12f,
    tint: Color? = null,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    val base = Modifier.size(size)
    val styled = if (tint != null) base.clip(CircleShape).background(tint) else base.glass(CircleShape, fill)
    Box(
        modifier = styled.clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
        content = content
    )
}
