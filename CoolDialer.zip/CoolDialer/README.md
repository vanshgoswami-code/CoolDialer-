# Cool Dialer

A simple open-source Android dialer built with Kotlin and Jetpack Compose.

## Features
- Dark dialpad with letters under the keys
- Call button and backspace
- Recents tab (call history, tap to load the number)
- Opens from `tel:` links and can be picked as a dialer

## Run it
1. Install Android Studio.
2. Open this folder (`File > Open`). Android Studio will sync Gradle and create the Gradle wrapper.
3. Plug in a phone (USB debugging on) or start an emulator, then press Run.

The first time you tap Call, Android asks for phone permission. The Recents tab asks for call-log permission.

## Notes
- Package: `com.example.cooldialer` (change it in `app/build.gradle.kts` and the manifest).
- To make it your default phone app you would also need an `InCallService` and the dialer role. This version hands calls to the system.

## License
Use and modify freely.
