# Cool Dialer

An open-source Android phone app with a glass look, built with Kotlin and Jetpack Compose.

## Features
- Frosted-glass keypad, recents list and bottom bar
- Its own call screen for incoming, outgoing and ongoing calls (answer, decline, mute, speaker, hold, keypad tones, timer)
- Incoming-call alert that works on the lock screen
- Opens from `tel:` links and can be your default phone app

## Use your own call screen
Open the app and tap **Set default** on the keypad screen, then choose Cool Dialer. Until then, calls use the system call screen.

## Build
Push the project to GitHub. The workflow in `.github/workflows/build.yml` builds `app-debug.apk` and saves it under the run's Artifacts. You can also open the folder in Android Studio.

Requires Android 10 (API 29) or newer.
